# Insurance ML App

A small full-stack machine learning app built on the Kaggle
[Medical Cost Personal Dataset](https://www.kaggle.com/datasets/mirichoi0218/insurance).

| Part | What it does |
|------|--------------|
| **Regression** (Linear Regression) | Predicts the insurance **charges** (a number) from age, sex, BMI, children, smoker, region |
| **Classification** (Logistic Regression, Decision Tree, Naive Bayes, SVM, Random Forest) | Predicts whether a person is a **smoker** (yes/no) from age, sex, BMI, children, region, charges |
| **Backend** (FastAPI) | `POST /predict/regression` and `POST /predict/classification` (the request says which classifier to use) |
| **Frontend** (HTML) | One page with a menu to choose the model; the matching form is shown |

## Project structure
Everything is in one folder (`Lab mid`):
```
Lab mid/
├── data/
│   └── raw/
│       └── insurance.csv       <- download from Kaggle (see below)
├── notebooks/
│   └── train.ipynb             <- trains all models and saves them in models/
├── models/                     <- the saved .joblib files (created by train.ipynb)
├── main.py                     <- FastAPI backend (also serves the page)
├── index.html                  <- frontend
├── requirements.txt
└── README.md
```

## How to run

1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```
2. **Download the dataset** from the Kaggle link above and save it as `data/raw/insurance.csv`.
3. **Train the models:** open `notebooks/train.ipynb` and click **Run All**. It prints R² and accuracy for every model and saves the `.joblib` model files in the `models/` folder.
4. **Start the backend** (keep this terminal open):
   ```bash
   uvicorn main:app --reload
   ```
5. **Open the app** from a second terminal (the backend must keep running in the first):
   ```bash
   start index.html               # Windows
   open index.html                # Mac
   ```
6. Pick a model from the menu at the top of the page, fill in the form and click the button.

API docs are available at http://127.0.0.1:8000/docs.

Run all commands from inside the `Lab mid` folder. Do not run `main.py` directly; the server is started by `uvicorn`.

## Results
Test set = 20% of the data. Paste the numbers printed by `train.ipynb`.

| Model | Score |
|-------|-------|
| Linear Regression (R²) | FILL_IN |
| Logistic Regression (accuracy) | FILL_IN |
| Decision Tree (accuracy) | FILL_IN |
| Naive Bayes (accuracy) | FILL_IN |
| SVM (accuracy) | FILL_IN |
| Random Forest (accuracy) | FILL_IN |

## Example API calls
```bash
curl -X POST http://127.0.0.1:8000/predict/regression \
  -H "Content-Type: application/json" \
  -d '{"age":35,"sex":"male","bmi":27.5,"children":1,"smoker":"no","region":"northeast"}'

curl -X POST http://127.0.0.1:8000/predict/classification \
  -H "Content-Type: application/json" \
  -d '{"model":"svm","age":35,"sex":"male","bmi":27.5,"children":1,"region":"northeast","charges":30000}'
```
`model` can be `logistic_regression`, `decision_tree`, `naive_bayes`, `svm` or `random_forest`.
