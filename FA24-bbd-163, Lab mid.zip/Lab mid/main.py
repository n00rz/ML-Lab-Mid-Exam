"""FastAPI backend: loads the saved models and serves predictions + the HTML page."""
from pathlib import Path
from typing import Literal

import joblib
import pandas as pd
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BASE = Path(__file__).parent

app = FastAPI(title="Insurance ML App")

# Allow the page to call the API even when it is opened directly as a file
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---- Load everything once at start-up (created by train.ipynb) ----
CLASSIFIER_NAMES = {
    "logistic_regression": "Logistic Regression",
    "decision_tree": "Decision Tree",
    "naive_bayes": "Naive Bayes",
    "svm": "SVM",
    "random_forest": "Random Forest",
}
reg_model = joblib.load(BASE / "models" / "regression_model.joblib")
clf_models = {key: joblib.load(BASE / "models" / f"classification_{key}.joblib") for key in CLASSIFIER_NAMES}

Sex = Literal["male", "female"]
Region = Literal["northeast", "northwest", "southeast", "southwest"]
ModelName = Literal["logistic_regression", "decision_tree", "naive_bayes", "svm", "random_forest"]


class RegressionInput(BaseModel):
    age: int = Field(ge=18, le=100)
    sex: Sex
    bmi: float = Field(gt=10, lt=70)
    children: int = Field(ge=0, le=10)
    smoker: Literal["yes", "no"]
    region: Region


class ClassificationInput(BaseModel):
    model: ModelName = "random_forest"   # which classifier to use
    age: int = Field(ge=18, le=100)
    sex: Sex
    bmi: float = Field(gt=10, lt=70)
    children: int = Field(ge=0, le=10)
    region: Region
    charges: float = Field(gt=0)


@app.post("/predict/regression")
def predict_regression(data: RegressionInput):
    row = pd.DataFrame([data.model_dump()])
    price = float(reg_model.predict(row)[0])
    return {
        "predicted_charges": round(max(price, 0), 2),
        "model_name": "Linear Regression",
    }


@app.post("/predict/classification")
def predict_classification(data: ClassificationInput):
    features = data.model_dump(exclude={"model"})
    row = pd.DataFrame([features])
    model = clf_models[data.model]
    label = str(model.predict(row)[0])
    proba = float(model.predict_proba(row)[0].max())
    return {
        "prediction": label,
        "is_smoker": label == "yes",
        "confidence": round(proba, 3),
        "model_name": CLASSIFIER_NAMES[data.model],
    }


@app.get("/")
def home():
    return FileResponse(BASE / "index.html")